from aviation_package.get_data import get_aviation_data

if __name__ == "__main__":
    get_aviation_data()

