import mysql.connector
from db_connection import connect_to_db
import pandas as pd
import warnings

def insert_cleaned_aviation_data():
    try:
        warnings.filterwarnings("ignore", category=UserWarning)
        warnings.filterwarnings("ignore", category=FutureWarning)
        
        credentials = connect_to_db()
        conn = mysql.connector.connect(
            host = credentials['host'],
            user = credentials['user'],
            password = credentials['password'],
            database = credentials['database'],
        )

        cursor = conn.cursor()
        df = pd.read_sql('SELECT * FROM aviation_data;', conn)

        # handling missing values
        df["airline_name"].replace("empty", pd.NA, inplace=True)
        df['arrival_estimated'].fillna(df['arrival_scheduled'], inplace = True) 
        df['departure_estimated'].fillna(df['departure_scheduled'], inplace = True) 
        df['departure_timezone'].fillna(df['arrival_timezone'],inplace = True)
        df["departure_airport"].fillna("Unknown Airport", inplace=True)
        df["arrival_airport"].fillna("Unknown Airport", inplace=True)
        df['arrival_timezone'].fillna("UTC", inplace=True)
        df['airline_name'].fillna('Unknown', inplace = True)
        df['flight_number'].fillna('Unknown', inplace=True)
        df['flight_icao'].fillna('Unknown', inplace=True)

        # handling duplicate data
        df = df.drop_duplicates(subset = df.columns.difference(['id']), keep = 'first')
        df = df.reset_index(drop = True)

        # reverting to original data type
        df['id'] = df['id'].astype('int64')
        df['flight_date'] = pd.to_datetime(df['flight_date'], errors='coerce')
        df['departure_scheduled'] = pd.to_datetime(df['departure_scheduled'], errors='coerce')
        df['departure_estimated'] = pd.to_datetime(df['departure_estimated'], errors='coerce')
        df['arrival_scheduled'] = pd.to_datetime(df['arrival_scheduled'], errors='coerce')
        df['arrival_estimated'] = pd.to_datetime(df['arrival_estimated'], errors='coerce')
        
        truncate_query = 'TRUNCATE TABLE aviation_data_cleaned;'
        cursor.execute(truncate_query)
        conn.commit()

        file = open('aviation_package/insert_cleaned_data_query.sql','r')
        query = file.read()
        file.close()

        values = [tuple(row) for row in df.itertuples(index=False, name=None)]
        cursor.executemany(query, values)
        conn.commit()
        print('Cleaned data inserted successfully')

        cursor.close()
        conn.close()

    except:
        print('Failed to insert data.')

insert_cleaned_aviation_data()